package run.halo.app.core.extension.content;

/** Shared API group, version, annotation, and checksum keys for content extensions. */
public enum Constant {
    ;

    public static final String GROUP = "content.halo.run";
    public static final String VERSION = "v1alpha1";

    public static final String LAST_READ_TIME_ANNO = "content.halo.run/last-read-time";
    public static final String PERMALINK_PATTERN_ANNO = "content.halo.run/permalink-pattern";

    public static final String CHECKSUM_CONFIG_ANNO = "checksum/config";

    public static final String CONTENT_CHECKSUM_ANNO = "checksum/content";
}
