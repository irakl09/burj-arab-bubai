package run.halo.app.core.attachment.thumbnail;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import java.net.URI;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.reactive.ServerWebExchangeContextFilter;
import reactor.core.publisher.Mono;
import run.halo.app.core.attachment.AttachmentChangedEvent;
import run.halo.app.core.attachment.ThumbnailSize;
import run.halo.app.core.extension.attachment.Attachment;
import run.halo.app.extension.ExtensionUtil;
import run.halo.app.extension.ListOptions;
import run.halo.app.extension.ReactiveExtensionClient;
import run.halo.app.extension.index.query.Queries;
import run.halo.app.infra.ExternalUrlSupplier;
import run.halo.app.infra.properties.HaloProperties;

/**
 * Implementation of {@link ThumbnailService}.
 *
 * <p>Caches thumbnail links in memory for better performance.
 *
 * @author johnniang
 * @since 2.22.0
 */
@Slf4j
@Component
class DefaultThumbnailService implements ThumbnailService {

    private static final Map<ThumbnailSize, URI> EMPTY_THUMBNAILS = Map.of();

    private final Cache<String, Map<ThumbnailSize, URI>> thumbnailCache;

    private final ReactiveExtensionClient client;

    private final ExternalUrlSupplier externalUrlSupplier;

    private final HaloProperties haloProperties;

    public DefaultThumbnailService(
            ReactiveExtensionClient client, ExternalUrlSupplier externalUrlSupplier, HaloProperties haloProperties) {
        this.client = client;
        this.externalUrlSupplier = externalUrlSupplier;
        this.haloProperties = haloProperties;
        this.thumbnailCache = Caffeine.newBuilder()
                // TODO make it configurable
                .maximumSize(10_000)
                .build();
    }

    @EventListener
    void handleAttachmentChangedEvent(AttachmentChangedEvent event) {
        updateCache(event.getAttachment());
    }

    void updateCache(Attachment attachment) {
        if (attachment.getStatus() == null) {
            return;
        }
        var permalink = attachment.getStatus().getPermalink();
        if (!StringUtils.hasText(permalink)) {
            return;
        }
        if (ExtensionUtil.isDeleted(attachment)) {
            thumbnailCache.invalidate(permalink);
            return;
        }
        var thumbnails = attachment.getStatus().getThumbnails();
        if (CollectionUtils.isEmpty(thumbnails)) {
            thumbnailCache.put(permalink, EMPTY_THUMBNAILS);
            return;
        }
        Map<ThumbnailSize, URI> validThumbnails = new HashMap<>();
        thumbnails.forEach((key, value) -> {
            var size = ThumbnailSize.optionalValueOf(key);
            if (size.isPresent() && StringUtils.hasText(value)) {
                validThumbnails.put(size.get(), URI.create(value));
            }
        });
        if (validThumbnails.isEmpty()) {
            thumbnailCache.put(permalink, EMPTY_THUMBNAILS);
        } else {
            thumbnailCache.put(permalink, Collections.unmodifiableMap(validThumbnails));
        }
    }

    @Override
    public Mono<URI> get(URI permalink, ThumbnailSize size) {
        return get(permalink).mapNotNull(thumbnails -> thumbnails.get(size));
    }

    @Override
    public Mono<Map<ThumbnailSize, URI>> get(URI permalink) {
        if (isThumbnailDisabled()) {
            return Mono.just(EMPTY_THUMBNAILS);
        }
        var encodedPermalink = URI.create(permalink.toASCIIString());
        if (!encodedPermalink.isAbsolute()) {
            // build permalinks
            return Mono.just(ThumbnailUtils.buildSrcsetMap(encodedPermalink));
        }
        // TODO Optimize concurrent requests for the same permalink
        return Mono.deferContextual(contextView -> {
            var externalUrl = ServerWebExchangeContextFilter.getExchange(contextView)
                    .map(exchange -> externalUrlSupplier.getURL(exchange.getRequest()))
                    .orElseGet(externalUrlSupplier::getRaw);
            // check if the permalink is from local site
            if (externalUrl != null && Objects.equals(externalUrl.getAuthority(), encodedPermalink.getAuthority())) {
                return Mono.just(ThumbnailUtils.buildSrcsetMap(encodedPermalink));
            }
            var permalinkString = encodedPermalink.toASCIIString();
            var thumbnails = thumbnailCache.getIfPresent(permalinkString);
            if (thumbnails != null) {
                return Mono.just(thumbnails);
            }
            // query from attachments
            var listOptions = ListOptions.builder()
                    .andQuery(Queries.equal("status.permalink", permalinkString))
                    .build();
            return client.listAll(Attachment.class, listOptions, ExtensionUtil.defaultSort())
                    .next()
                    // Here we allow concurrent updates
                    .doOnNext(this::updateCache)
                    .mapNotNull(attachment -> this.thumbnailCache.getIfPresent(permalinkString))
                    .switchIfEmpty(Mono.fromSupplier(() -> {
                        // No attachment or no thumbnails, cache empty map to avoid cache miss again and
                        // again.
                        this.thumbnailCache.put(permalinkString, EMPTY_THUMBNAILS);
                        return EMPTY_THUMBNAILS;
                    }));
        });
    }

    private boolean isThumbnailDisabled() {
        return haloProperties.getAttachment().getThumbnail().isDisabled();
    }
}
